# GujJobsTracker — Setup Guide for Yogesh

## How it works
- Every day at **8:00 AM IST**, GitHub automatically runs the scraper
- Scraper checks OJAS, GPSC, GSSSB, NFSU, ISRO, SMC for new jobs
- Updates `data/jobs.json` automatically
- Your website reads this file and shows fresh data
- You get an **email alert** if new jobs are found

---

## Step 1 — Upload ALL these files to your GitHub repo

Your repo: `vasavayogu44-ux/govjob`

Upload in this exact structure:
```
govjob/
├── index.html                        ← main website
├── data/
│   └── jobs.json                     ← job data (auto-updated)
├── scraper/
│   ├── scrape.py                     ← the scraper script
│   └── requirements.txt              ← Python packages
└── .github/
    └── workflows/
        └── daily-scraper.yml         ← GitHub Actions schedule
```

---

## Step 2 — Add Email Notification (Optional but Recommended)

To get email alerts when new jobs are posted:

1. Go to your Gmail → Settings → Security → **App Passwords**
2. Create a new App Password for "Mail"
3. In your GitHub repo → **Settings** → **Secrets and variables** → **Actions**
4. Add these 3 secrets:
   - `GMAIL_USER` = your Gmail address (e.g. yogeshvasava3823@gmail.com)
   - `GMAIL_APP_PASSWORD` = the 16-character app password from step 2
   - `NOTIFY_EMAIL` = email where you want alerts (can be same Gmail)

---

## Step 3 — Enable GitHub Actions

1. In your repo → click **Actions** tab
2. If it says "Workflows aren't running" → click **Enable**
3. Done! It will now run every day at 8 AM IST

---

## Step 4 — Test it manually

1. Go to **Actions** tab in your repo
2. Click **Daily Jobs Scraper** in the left list
3. Click **Run workflow** → **Run workflow** (green button)
4. Watch it run live — takes about 30–60 seconds
5. Check your website after — data will be fresh!

---

## How to add new jobs manually (if needed)

Edit `data/jobs.json` and add a new entry to the `"jobs"` array.
Copy the format of an existing entry.

---

## Portals being monitored
- https://ojas.gujarat.gov.in
- https://gpsc.gujarat.gov.in
- https://gsssb.gujarat.gov.in
- https://nfsu.ac.in/career
- https://www.isro.gov.in/Careers.html
- https://www.suratmunicipal.gov.in/information/recruitment

---

## Your live website
https://vasavayogu44-ux.github.io/govjob/
